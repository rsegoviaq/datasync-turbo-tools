# Changelog

All notable changes to DataSync Turbo Tools will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2025-10-30

### Added
- **Direct AWS Credentials Support**: Configure AWS credentials directly without requiring AWS CLI profile setup
  - New config options: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`
  - Ideal for CI/CD environments, containers, or systems without AWS CLI profile configuration
- **Enhanced AWS CLI Installation Guidance**: Comprehensive installation instructions when AWS CLI is not detected
  - Platform-specific instructions (Linux, macOS)
  - Package manager alternatives
  - Direct download links

### Changed
- **Configuration Template**: Updated `production.env.template` with clear authentication method selection
  - Two authentication methods: AWS Profile (Method 1) or Direct Credentials (Method 2)
  - Detailed comments explaining each approach and security considerations
- **Upload Script Authentication**: Enhanced credential detection and validation
  - Displays active authentication method during execution
  - Shows partial access key for verification (first 8 characters)
  - Falls back to default AWS credentials chain if neither method configured
- **Installer**: Updated configuration setup guidance to explain both authentication methods
  - Clear instructions for choosing between profile and credentials
  - Improved user experience during initial setup

### Improved
- Help documentation now includes complete AWS credential configuration options
- Better error messages and validation for AWS authentication
- Configuration display shows which authentication method is active

### Notes
- **Backward Compatible**: Existing configurations using `AWS_PROFILE` continue to work without changes
- **Security Best Practice**: AWS profiles still recommended for local/development environments
- **Profile Priority**: If both profile and credentials are set, profile takes precedence

---

## [1.0.0] - 2025-10-28

### Added
- Initial production release
- s5cmd integration for high-performance S3 uploads (5-12x faster than AWS CLI)
- Production-optimized configuration for 3+ Gbps networks
- Comprehensive logging system (text and JSON formats)
- Throughput monitoring and performance metrics
- Health checks and status reporting
- Automated deployment with systemd integration
- Log rotation with logrotate
- Alert system for monitoring failures
- Benchmark tool for performance testing
- Installation verification script
- Complete documentation and guides

### Performance
- Concurrency: 64 parallel operations
- Part size: 128MB for multipart uploads
- Workers: 32 threads
- Checksum: CRC64NVME (fastest algorithm)
- Storage class: INTELLIGENT_TIERING
- Expected throughput: 200-300 MB/s on 3 Gbps networks

### Security
- AWS IAM credential support
- AWS profile support
- Checksum verification (CRC64NVME/SHA256)
- Server-side encryption support (KMS)
- Secure log handling

### Documentation
- Quick start guide (5 minutes)
- Configuration reference
- Monitoring guide
- Troubleshooting guide
- Performance tuning guide

---

## Release Notes

### Version 1.0.0

This is the first production release of DataSync Turbo Tools, providing enterprise-ready S3 upload capabilities with significant performance improvements over standard AWS CLI.

**Key Features:**
- **High Performance**: 5-12x faster uploads than AWS CLI
- **Production Ready**: Comprehensive error handling and monitoring
- **Easy Deployment**: One-command installation and setup
- **Professional Monitoring**: Health checks, alerts, and metrics
- **Complete Documentation**: Step-by-step guides and examples

**Tested Environments:**
- Linux (Ubuntu 20.04+, RHEL 8+, Amazon Linux 2)
- macOS (10.15+)
- WSL2 (Windows Subsystem for Linux)

**Requirements:**
- Bash 4.0+
- AWS CLI installed and configured
- Network: 1 Gbps+ recommended (optimized for 3+ Gbps)
- Disk: Sufficient space for logs and temporary files
- AWS: S3 bucket with appropriate IAM permissions

**Getting Started:**
```bash
./install.sh
nano config/production.env
./tools/verify-installation.sh
./scripts/datasync-s5cmd.sh --dry-run
```

For full documentation, see README.md.

